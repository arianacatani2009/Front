export const CardPerfil = () => {
    return (
        <div className="bg-white border border-slate-200 h-full p-4 
                        flex flex-col items-center justify-between shadow-xl rounded-lg">

            <div>
                <img src="https://cdn-icons-png.flaticon.com/512/4715/4715329.png" alt="img-client" className="m-auto " width={120} height={120} />
            </div>
            <div className="self-start">
                <p>Nombre: </p>
            </div>
            <div className="self-start">
                <p>Nombre: </p>
            </div >
            <div className="self-start">
                <p>Nombre: </p>
            </div>
            <div className="self-start">
                <p>Nombre: </p>
            </div>
            <div className="self-start">
                <p>Nombre: </p>
            </div>
            <div className="self-start">
                <p>Nombre: </p>
            </div>
            <div className="self-start">
                <p>Detalles: </p>
            </div>
        </div>
    )
}
